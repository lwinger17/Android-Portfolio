package com.wingerlucas.portfolio

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

import android.util.Log

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val app = applicationContext as MyApp
        Log.d("MainActivity", "Interacting with MyApp.")
        app.applyThemeImages(this)  // Call this after the layout is inflated

        // Other setup for navigation and click listeners...
        val mainLink = findViewById<ImageView>(R.id.mainLink)
        val bioLink = findViewById<ImageView>(R.id.bioLink)
        val projectLink = findViewById<ImageView>(R.id.projectLink)
        val settingsButton = findViewById<ImageView>(R.id.settingsButton)

        // Log here to confirm the views are initialized
        Log.d("MainActivity", "mainLink: $mainLink, bioLink: $bioLink, projectLink: $projectLink")


        mainLink.setOnClickListener {
            // Do nothing since the user is already on this screen
        }

        bioLink.setOnClickListener {
            val bioIntent = Intent(this, BiographyActivity::class.java)
            startActivity(bioIntent)
            finish()  // Prevents stacking multiple activities
        }

        projectLink.setOnClickListener {
            val projectIntent = Intent(this, ProjectsActivity::class.java)
            startActivity(projectIntent)
            finish()  // Close BiographyActivity to prevent stacking
        }

        settingsButton.setOnClickListener {
            val settingsIntent = Intent(this, SettingsActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(settingsIntent)
        }

        // Social icon redirects
        val linkedInIcon = findViewById<ImageView>(R.id.linkedIn)
        val githubIcon = findViewById<ImageView>(R.id.github)
        val webLink = findViewById<ImageView>(R.id.website)

        linkedInIcon.setOnClickListener {
            openUrl("https://www.linkedin.com/in/lucas-winger-3842112a3/")
        }

        githubIcon.setOnClickListener {
            openUrl("https://github.com/lwinger17")
        }

        webLink.setOnClickListener {
            openUrl("https://lucaswinger.com/")
        }
    }

    // Function to open URLs in a browser
    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }
}

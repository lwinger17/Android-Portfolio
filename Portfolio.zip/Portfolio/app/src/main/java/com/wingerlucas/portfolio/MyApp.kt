package com.wingerlucas.portfolio

import android.app.Application
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.util.Log

class MyApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Log to confirm MyApp initialization
        Log.d("MyApp", "MyApp initialized.")

        // Load the theme preference (default = dark mode)
        val prefs: SharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val isDarkMode = prefs.getBoolean("DarkMode", true) // Default to dark mode if not set

        // Apply the selected mode (dark or light)
        AppCompatDelegate.setDefaultNightMode(
            if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    // Function to apply the appropriate images based on the current theme
    fun applyThemeImages(activity: AppCompatActivity) {
        val isDarkMode = activity.getSharedPreferences("AppSettings", MODE_PRIVATE)
            .getBoolean("DarkMode", true) // Default to dark mode if not set

        val modePrefix = if (isDarkMode) "dark_" else "light_"

        // Set the images for various views based on the theme
        val mainLink = activity.findViewById<ImageView>(R.id.mainLink)
        val bioLink = activity.findViewById<ImageView>(R.id.bioLink)
        val projectLink = activity.findViewById<ImageView>(R.id.projectLink)
        val settingsButton = activity.findViewById<ImageView>(R.id.settingsButton)

        Log.d("MyApp", "mainLink: $mainLink, bioLink: $bioLink, projectLink: $projectLink")

        // Log if any view is null
        if (mainLink == null || bioLink == null || projectLink == null || settingsButton == null) {
            Log.e("MyApp", "One or more ImageViews are null. Please check the layout.")
        } else {
            // Set the images if all views are initialized
            mainLink?.setImageResource(getImageResource("${modePrefix}home"))
            bioLink?.setImageResource(getImageResource("${modePrefix}bio"))
            projectLink?.setImageResource(getImageResource("${modePrefix}project"))
            settingsButton?.setImageResource(getImageResource("${modePrefix}settings"))
        }
    }

    // Function to get image resources based on the theme
    private fun getImageResource(name: String): Int {
        return when (name) {
            "dark_home" -> R.drawable.dark_home
            "light_home" -> R.drawable.light_home
            "dark_bio" -> R.drawable.dark_bio
            "light_bio" -> R.drawable.light_bio
            "dark_project" -> R.drawable.dark_proj
            "light_project" -> R.drawable.light_proj
            "dark_settings" -> R.drawable.dark_settings
            "light_settings" -> R.drawable.light_settings
            "dark_link" -> R.drawable.dark_link // LinkedIn
            "light_link" -> R.drawable.light_link
            "dark_git" -> R.drawable.dark_git // GitHub
            "light_git" -> R.drawable.light_git
            "dark_web" -> R.drawable.dark_web // Website
            "light_web" -> R.drawable.light_web
            else -> R.drawable.user
        }
    }
}

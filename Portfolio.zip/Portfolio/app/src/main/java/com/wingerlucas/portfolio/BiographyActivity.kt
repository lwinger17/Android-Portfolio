package com.wingerlucas.portfolio

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class BiographyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.biography)  // Corrected layout reference!

        // Apply theme images based on the current mode (light or dark)
        val app = applicationContext as MyApp
        app.applyThemeImages(this)  // Call this after the layout is inflated

        // Initialize navigation ImageViews
        val mainLink = findViewById<ImageView>(R.id.mainLink)
        val bioLink = findViewById<ImageView>(R.id.bioLink)
        val projectLink = findViewById<ImageView>(R.id.projectLink)
        val settingsButton = findViewById<ImageView>(R.id.settingsButton)

        mainLink.setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)
            finish()
        }

        bioLink.setOnClickListener {
            // Do nothing since the user is already on this screen
        }

        projectLink.setOnClickListener {
            val projectIntent = Intent(this, ProjectsActivity::class.java)
            startActivity(projectIntent)
            finish()  // Close BiographyActivity to prevent stacking
        }

        settingsButton.setOnClickListener {
            val settingsIntent = Intent(this, SettingsActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(settingsIntent)
        }
    }
}

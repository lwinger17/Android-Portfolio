package com.wingerlucas.portfolio

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ImageView
import com.google.android.material.materialswitch.MaterialSwitch
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class SettingsActivity : AppCompatActivity() {
    private lateinit var darkModeSwitch: MaterialSwitch
    private lateinit var sharedPreferences: SharedPreferences

    private lateinit var mainLink: ImageView
    private lateinit var bioLink: ImageView
    private lateinit var projectLink: ImageView
    private lateinit var backButton: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("DarkMode", true)

        setContentView(R.layout.settings)

        // Apply theme images based on the current mode (light or dark)
        val app = applicationContext as MyApp
        app.applyThemeImages(this)

        mainLink = findViewById(R.id.mainLink)
        bioLink = findViewById(R.id.bioLink)
        projectLink = findViewById(R.id.projectLink)
        backButton = findViewById(R.id.back)
        darkModeSwitch = findViewById(R.id.darkModeSwitch)

        darkModeSwitch.isChecked = isDarkMode


        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            with(sharedPreferences.edit()) {
                putBoolean("DarkMode", isChecked)
                apply()
            }

            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )

            recreate() // Optional, forces UI update instantly
        }

        mainLink.setOnClickListener { navigateToMain() }
        bioLink.setOnClickListener {
            startActivity(Intent(this, BiographyActivity::class.java))
            finish()
        }
        projectLink.setOnClickListener {
            startActivity(Intent(this, ProjectsActivity::class.java))
            finish()
        }
        backButton.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}

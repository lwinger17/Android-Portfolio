package com.wingerlucas.portfolio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class DetailedClubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.project_detail_club)

        // Load the current dark mode setting
        val sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("DarkMode", true) // Default to dark mode if not set

        // Apply dark mode or light mode
        AppCompatDelegate.setDefaultNightMode(
            if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        // Initialize navigation ImageViews after layout is inflated
        val mainLink = findViewById<ImageView>(R.id.mainLink)
        val bioLink = findViewById<ImageView>(R.id.bioLink)
        val backButton = findViewById<ImageView>(R.id.back)
        val projectLink = findViewById<ImageView>(R.id.projectLink)
        val linkIcon = findViewById<ImageView>(R.id.linkIcon)

        // Use the app instance to apply theme-based images after initializing views
        val app = applicationContext as MyApp
        app.applyThemeImages(this)

        // Navigate back to MainActivity (Home)
        mainLink.setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)
            finish()  // Prevent stacking multiple activities
        }

        // Navigate to BiographyActivity
        bioLink.setOnClickListener {
            val bioIntent = Intent(this, BiographyActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(bioIntent)
            finish()  // Prevent reloading BiographyActivity
        }

        // Navigate to ProjectsActivity
        projectLink.setOnClickListener {
            val projectIntent = Intent(this, ProjectsActivity::class.java)
            startActivity(projectIntent)
            finish()  // Prevent stacking multiple activities
        }

        // Back button to go back to the previous activity
        backButton.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Open a URL in the browser when the LinkIcon is clicked
        linkIcon.setOnClickListener {
            val url = "https://github.com/lwinger17/Club-Website" // Replace with actual URL
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(browserIntent)
        }
    }
}

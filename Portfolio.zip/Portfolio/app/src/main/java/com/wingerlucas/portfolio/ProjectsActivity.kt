package com.wingerlucas.portfolio

import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ProjectsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.projects)  // Ensure projects.xml is the correct layout

        // Apply theme images based on the current mode (light or dark)
        val app = applicationContext as MyApp
        app.applyThemeImages(this)

        // Initialize navigation ImageViews
        val mainLink = findViewById<ImageView>(R.id.mainLink)
        val bioLink = findViewById<ImageView>(R.id.bioLink)
        val projectLink = findViewById<ImageView>(R.id.projectLink)
        val settingsButton = findViewById<ImageView>(R.id.settingsButton)

        // Initialize project-specific FrameLayouts
        val partyProject = findViewById<FrameLayout>(R.id.partyProject)
        val blackjackProject = findViewById<FrameLayout>(R.id.blackjackProject)
        val portProject = findViewById<FrameLayout>(R.id.portProject)
        val clubProject = findViewById<FrameLayout>(R.id.clubProject)
        val aiProject = findViewById<FrameLayout>(R.id.AIProject)
        val replitProject = findViewById<FrameLayout>(R.id.replitProject)

        // Image click listeners
        mainLink.setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)
            finish()  // Prevent stacking multiple activities
        }

        bioLink.setOnClickListener {
            val bioIntent = Intent(this, BiographyActivity::class.java)
            startActivity(bioIntent)
            finish()  // Prevent stacking multiple activities
        }

        projectLink.setOnClickListener {
            // Do nothing since the user is already on this screen
        }

        settingsButton.setOnClickListener {
            val settingsIntent = Intent(this, SettingsActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(settingsIntent)
        }

        // Navigation for individual project details
        partyProject.setOnClickListener {
            startActivity(Intent(this, DetailedPartyActivity::class.java))
        }

        blackjackProject.setOnClickListener {
            startActivity(Intent(this, DetailedBlackjackActivity::class.java))
        }

        portProject.setOnClickListener {
            startActivity(Intent(this, DetailedPortActivity::class.java))
        }

        clubProject.setOnClickListener {
            startActivity(Intent(this, DetailedClubActivity::class.java))
        }

        aiProject.setOnClickListener {
            startActivity(Intent(this, DetailedAiActivity::class.java))
        }

        replitProject.setOnClickListener {
            startActivity(Intent(this, Detailed100Activity::class.java))
        }
    }
}
